<?php
require_once "vendor/autoload.php";
header('Content-type: text/html; charset=utf-8');

$objects = json_decode(file_get_contents("config.json"))->objects;
$currentTime = time();

foreach ($objects as $object) {
     $time = json_decode(file_get_contents("storage/$object->id.json"))->time;
     // Если пошло 60 сек
     if ($time + 60 < $currentTime) {
         echo "Давно не было запросов у объекта $object->name в ".date('h:i:s', $time). "\r\n";
     }
}