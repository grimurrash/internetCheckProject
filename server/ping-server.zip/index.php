<?php
//require_once 'vendor/autoload.php';
header('Content-type: text/html; charset=utf-8');
$objectId = $_GET['objectId'];
$time = time();

$objects = json_decode(file_get_contents("config.json"))->objects;
$key = array_search($objectId, array_column($objects, 'id'));
$object = $objects[$key];

file_put_contents("storage/$object->id.json", json_encode([
    'time' => $time
]));

$logFilePath = 'storage/log.txt';
$str = file_get_contents($logFilePath);
$str .= "Обновление времени у объекта $objectId: " . date('H:i:s', $time) . "\r\n";
file_put_contents($logFilePath, $str);